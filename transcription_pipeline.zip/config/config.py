from pathlib import Path

DEFAULT_CONFIG_PATH = Path("config/settings.toml")
